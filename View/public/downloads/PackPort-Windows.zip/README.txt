PackPort Windows Quickstart Guide
==================================

1. Install Node.js (version 18 or newer) from https://nodejs.org
2. Open PowerShell or Command Prompt and run:
   npm install -g packport-cli

3. Link your machine with your unique Agent Code from the dashboard:
   packport link <YOUR_AGENT_CODE>

4. Start the background telemetry service:
   packport start

Documentation: https://pack-port-nine.vercel.app/docs
